# Module SV4 - Phân công gia sư, lịch học và điểm danh

**Người thực hiện:** SV4 - Nguyễn Việt Cường (hãy sửa tên/mã SV nếu thông tin nhóm yêu cầu khác).

## Chức năng
- Phân công gia sư chỉ khi gia sư đang hoạt động, lớp đang mở và chuyên môn khớp môn học.
- Không tạo phân công đang hiệu lực trùng gia sư/lớp.
- Lập lịch và kiểm tra trùng lịch gia sư, lớp, học viên đã xác nhận đăng ký.
- Điều kiện chồng lấn thời gian: `batDauMoi < ketThucCu && batDauCu < ketThucMoi`.
- Hủy buổi học hoặc đánh dấu hoàn thành.
- Điểm danh chỉ học viên có đăng ký đã xác nhận; không điểm danh lịch đã hủy.
- Một học viên chỉ có một bản ghi cho mỗi buổi (unique index); ghi lại lần nữa sẽ cập nhật bản ghi cũ.
- Có dữ liệu mẫu để chạy thử.

## Cách chạy trên máy tính
1. Cài **.NET 8 SDK**.
2. Giải nén thư mục.
3. Mở Terminal/CMD tại thư mục có file `.csproj`.
4. Chạy:
   ```bash
   dotnet restore
   dotnet run
   ```
5. Mở URL được hiện trong terminal (thường là `https://localhost:xxxx` hoặc `http://localhost:xxxx`).

Ứng dụng tạo file cơ sở dữ liệu `sv4_giasu.db` tự động ở lần chạy đầu.

## Đẩy lên GitHub
Tạo nhánh riêng, ví dụ `sv4-phancong-lichhoc-diemdanh`, rồi đặt thư mục dự án vào repository của nhóm. Commit theo quy ước của nhóm:
```bash
git checkout -b sv4-phancong-lichhoc-diemdanh
git add .
git commit -m "[MSSV-HoTen] [SV4] Phan cong, lich hoc, diem danh"
git push -u origin sv4-phancong-lichhoc-diemdanh
```
Thay `MSSV-HoTen` bằng mã sinh viên và họ tên chính xác theo yêu cầu giảng viên.

## Lưu ý tích hợp với dự án nhóm
Đây là project độc lập để bạn có thể lưu/push và chạy thử ngay vì file `.slnx` được gửi chưa kèm `.csproj` và mã nguồn chính. Các Entity `GiaSu`, `LopHoc`, `HocVien`, `DangKyLop` trong project này là bản tối giản phục vụ chạy thử. Khi nhập vào project chung, cần dùng Entity/DbContext của SV1-SV3 thay vì tạo bảng trùng; thống nhất tên thuộc tính trạng thái đăng ký, chuyên môn và thời gian với cả nhóm. Chỉ một người trong nhóm chạy migration tại một thời điểm.
