// Người thực hiện: SV4 - Nguyễn Việt Cường (hãy sửa tên/mã SV nếu cần)
// Nội dung: Nghiệp vụ phân công và phát hiện lịch chồng lấn: bd1 < kt2 && bd2 < kt1.
using Microsoft.EntityFrameworkCore;
using SV4_PhanCongLichHocDiemDanh.Data;
using SV4_PhanCongLichHocDiemDanh.Models;

namespace SV4_PhanCongLichHocDiemDanh;

public class ScheduleService(AppDbContext db)
{
    public async Task<string?> ValidateAssignment(int giaSuId, int lopHocId)
    {
        var gs = await db.GiaSus.FindAsync(giaSuId);
        var lop = await db.LopHocs.FindAsync(lopHocId);
        if (gs is null || lop is null) return "Không tìm thấy gia sư hoặc lớp học.";
        if (!gs.DangHoatDong) return "Chỉ được phân công gia sư đang hoạt động.";
        if (!lop.DangMo) return "Không thể phân công vào lớp đã đóng.";
        if (!string.Equals(gs.ChuyenMon.Trim(), lop.MonHoc.Trim(), StringComparison.OrdinalIgnoreCase))
            return "Chuyên môn gia sư không phù hợp với môn học của lớp.";
        var exists = await db.PhanCongGiaSus.AnyAsync(x => x.GiaSuId == giaSuId &&
            x.LopHocId == lopHocId && x.TrangThai == "Đang hiệu lực");
        if (exists) return "Gia sư đã được phân công vào lớp này.";
        return null;
    }

    public async Task<string?> ValidateSchedule(int assignmentId, DateTime start, DateTime end, int? excludeId = null)
    {
        if (end <= start) return "Thời gian kết thúc phải sau thời gian bắt đầu.";
        var pc = await db.PhanCongGiaSus.Include(x => x.GiaSu).Include(x => x.LopHoc)
            .FirstOrDefaultAsync(x => x.Id == assignmentId);
        if (pc is null || pc.TrangThai != "Đang hiệu lực") return "Phân công không tồn tại hoặc đã ngừng hiệu lực.";
        if (pc.GiaSu is null || !pc.GiaSu.DangHoatDong) return "Gia sư không còn hoạt động.";

        var existing = await db.LichHocs.Include(x => x.PhanCongGiaSu)
            .Where(x => x.TrangThai != "Đã hủy" && (!excludeId.HasValue || x.Id != excludeId.Value))
            .ToListAsync();
        foreach (var item in existing)
        {
            // Hai khoảng thời gian giao nhau khi start < item.End && item.Start < end.
            var overlap = start < item.KetThuc && item.BatDau < end;
            if (!overlap) continue;
            if (item.PhanCongGiaSu?.GiaSuId == pc.GiaSuId)
                return $"Gia sư đã có lịch trùng (lịch #{item.Id}).";
            if (item.PhanCongGiaSu?.LopHocId == pc.LopHocId)
                return $"Lớp học đã có lịch trùng (lịch #{item.Id}).";

            // Kiểm tra học viên có đăng ký xác nhận ở cả hai lớp.
            var currentStudentIds = await db.DangKyLops.Where(x => x.LopHocId == pc.LopHocId &&
                x.TrangThai == "Đã xác nhận").Select(x => x.HocVienId).ToListAsync();
            var otherClassId = item.PhanCongGiaSu?.LopHocId;
            if (otherClassId.HasValue)
            {
                var otherStudentIds = await db.DangKyLops.Where(x => x.LopHocId == otherClassId.Value &&
                    x.TrangThai == "Đã xác nhận").Select(x => x.HocVienId).ToListAsync();
                if (currentStudentIds.Intersect(otherStudentIds).Any())
                    return $"Có học viên đăng ký hai lớp bị trùng lịch (lịch #{item.Id}).";
            }
        }
        return null;
    }
}
