// Người thực hiện: SV4 - Nguyễn Việt Cường (hãy sửa tên/mã SV nếu cần)
// Nội dung: Dữ liệu mẫu tối thiểu cho gia sư, lớp, học viên, phân công, lịch và đăng ký.
using SV4_PhanCongLichHocDiemDanh.Models;

namespace SV4_PhanCongLichHocDiemDanh.Data;

public static class SeedData
{
    public static void Initialize(AppDbContext db)
    {
        if (db.GiaSus.Any()) return;
        var gs1 = new GiaSu { HoTen = "Nguyễn Minh Anh", ChuyenMon = "Toán", DangHoatDong = true };
        var gs2 = new GiaSu { HoTen = "Trần Quốc Bảo", ChuyenMon = "Tiếng Anh", DangHoatDong = true };
        var gs3 = new GiaSu { HoTen = "Gia sư đã ngừng hoạt động", ChuyenMon = "Toán", DangHoatDong = false };
        var lop1 = new LopHoc { TenLop = "Toán 9A", MonHoc = "Toán", DangMo = true };
        var lop2 = new LopHoc { TenLop = "Tiếng Anh 8A", MonHoc = "Tiếng Anh", DangMo = true };
        var hv1 = new HocVien { HoTen = "Lê Thu Hà" };
        var hv2 = new HocVien { HoTen = "Phạm Đức Long" };
        db.AddRange(gs1, gs2, gs3, lop1, lop2, hv1, hv2);
        db.SaveChanges();
        var pc1 = new PhanCongGiaSu { GiaSuId = gs1.Id, LopHocId = lop1.Id };
        var pc2 = new PhanCongGiaSu { GiaSuId = gs2.Id, LopHocId = lop2.Id };
        db.AddRange(pc1, pc2);
        db.SaveChanges();
        var now = DateTime.Today.AddDays(1).AddHours(9);
        var lich1 = new LichHoc { PhanCongGiaSuId = pc1.Id, BatDau = now, KetThuc = now.AddHours(1.5) };
        var lich2 = new LichHoc { PhanCongGiaSuId = pc2.Id, BatDau = now.AddHours(2), KetThuc = now.AddHours(3.5) };
        db.AddRange(lich1, lich2);
        db.AddRange(
            new DangKyLop { HocVienId = hv1.Id, LopHocId = lop1.Id, TrangThai = "Đã xác nhận" },
            new DangKyLop { HocVienId = hv2.Id, LopHocId = lop1.Id, TrangThai = "Đã xác nhận" },
            new DangKyLop { HocVienId = hv1.Id, LopHocId = lop2.Id, TrangThai = "Chờ xác nhận" });
        db.SaveChanges();
    }
}
