// Người thực hiện: SV4 - Nguyễn Việt Cường (hãy sửa tên/mã SV nếu cần)
// Nội dung: Cấu hình bảng, quan hệ và ràng buộc không điểm danh trùng một học viên/buổi.
using Microsoft.EntityFrameworkCore;
using SV4_PhanCongLichHocDiemDanh.Models;

namespace SV4_PhanCongLichHocDiemDanh.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<GiaSu> GiaSus => Set<GiaSu>();
    public DbSet<LopHoc> LopHocs => Set<LopHoc>();
    public DbSet<HocVien> HocViens => Set<HocVien>();
    public DbSet<DangKyLop> DangKyLops => Set<DangKyLop>();
    public DbSet<PhanCongGiaSu> PhanCongGiaSus => Set<PhanCongGiaSu>();
    public DbSet<LichHoc> LichHocs => Set<LichHoc>();
    public DbSet<DiemDanh> DiemDanhs => Set<DiemDanh>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DiemDanh>()
            .HasIndex(x => new { x.LichHocId, x.DangKyLopId }).IsUnique();
        modelBuilder.Entity<PhanCongGiaSu>().HasOne(x => x.GiaSu).WithMany().HasForeignKey(x => x.GiaSuId);
        modelBuilder.Entity<PhanCongGiaSu>().HasOne(x => x.LopHoc).WithMany().HasForeignKey(x => x.LopHocId);
        modelBuilder.Entity<LichHoc>().HasOne(x => x.PhanCongGiaSu).WithMany().HasForeignKey(x => x.PhanCongGiaSuId);
        modelBuilder.Entity<DiemDanh>().HasOne(x => x.LichHoc).WithMany().HasForeignKey(x => x.LichHocId);
        modelBuilder.Entity<DiemDanh>().HasOne(x => x.DangKyLop).WithMany().HasForeignKey(x => x.DangKyLopId);
    }
}
