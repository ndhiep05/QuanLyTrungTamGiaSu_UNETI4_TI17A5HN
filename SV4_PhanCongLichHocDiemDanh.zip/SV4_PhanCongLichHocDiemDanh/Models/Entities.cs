// Người thực hiện: SV4 - Nguyễn Việt Cường (hãy sửa tên/mã SV nếu cần)
// Nội dung: Các entity độc lập để chạy thử module SV4. Khi tích hợp nhóm, đối chiếu với Entity của SV1-SV3.
using System.ComponentModel.DataAnnotations;

namespace SV4_PhanCongLichHocDiemDanh.Models;

public class GiaSu
{
    public int Id { get; set; }
    [Required, StringLength(100)] public string HoTen { get; set; } = "";
    [Required, StringLength(100)] public string ChuyenMon { get; set; } = "";
    public bool DangHoatDong { get; set; } = true;
}
public class LopHoc
{
    public int Id { get; set; }
    [Required, StringLength(100)] public string TenLop { get; set; } = "";
    [Required, StringLength(100)] public string MonHoc { get; set; } = "";
    public bool DangMo { get; set; } = true;
}
public class HocVien
{
    public int Id { get; set; }
    [Required, StringLength(100)] public string HoTen { get; set; } = "";
}
public class DangKyLop
{
    public int Id { get; set; }
    public int HocVienId { get; set; }
    public HocVien? HocVien { get; set; }
    public int LopHocId { get; set; }
    public LopHoc? LopHoc { get; set; }
    // Chỉ "Đã xác nhận" mới được đưa vào lịch/điểm danh.
    [Required] public string TrangThai { get; set; } = "Đã xác nhận";
}
public class PhanCongGiaSu
{
    public int Id { get; set; }
    public int GiaSuId { get; set; }
    public GiaSu? GiaSu { get; set; }
    public int LopHocId { get; set; }
    public LopHoc? LopHoc { get; set; }
    public DateTime NgayPhanCong { get; set; } = DateTime.Today;
    [Required] public string TrangThai { get; set; } = "Đang hiệu lực";
}
public class LichHoc
{
    public int Id { get; set; }
    public int PhanCongGiaSuId { get; set; }
    public PhanCongGiaSu? PhanCongGiaSu { get; set; }
    [Required] public DateTime BatDau { get; set; }
    [Required] public DateTime KetThuc { get; set; }
    [Required] public string TrangThai { get; set; } = "Đã lên lịch";
    [StringLength(500)] public string? GhiChu { get; set; }
}
public class DiemDanh
{
    public int Id { get; set; }
    public int LichHocId { get; set; }
    public LichHoc? LichHoc { get; set; }
    public int DangKyLopId { get; set; }
    public DangKyLop? DangKyLop { get; set; }
    [Required] public string TrangThai { get; set; } = "Có mặt";
    public DateTime ThoiDiemDiemDanh { get; set; } = DateTime.Now;
    [StringLength(500)] public string? GhiChu { get; set; }
}
