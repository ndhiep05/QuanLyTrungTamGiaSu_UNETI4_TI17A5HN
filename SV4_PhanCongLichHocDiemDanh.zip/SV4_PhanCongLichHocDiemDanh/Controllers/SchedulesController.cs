// Người thực hiện: SV4 - Nguyễn Việt Cường (hãy sửa tên/mã SV nếu cần)
// Nội dung: Tạo lịch, kiểm tra trùng gia sư/lớp/học viên, hủy và hoàn thành buổi học.
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SV4_PhanCongLichHocDiemDanh.Data;
using SV4_PhanCongLichHocDiemDanh.Models;

namespace SV4_PhanCongLichHocDiemDanh.Controllers;

public class SchedulesController(AppDbContext db, ScheduleService service) : Controller
{
    public async Task<IActionResult> Index() => View(await db.LichHocs
        .Include(x => x.PhanCongGiaSu)!.ThenInclude(x => x!.GiaSu)
        .Include(x => x.PhanCongGiaSu)!.ThenInclude(x => x!.LopHoc)
        .OrderBy(x => x.BatDau).ToListAsync());

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        await LoadAssignments();
        return View(new LichHoc { BatDau = DateTime.Today.AddDays(1).AddHours(9), KetThuc = DateTime.Today.AddDays(1).AddHours(10) });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(LichHoc model)
    {
        var error = await service.ValidateSchedule(model.PhanCongGiaSuId, model.BatDau, model.KetThuc);
        if (error is not null) ModelState.AddModelError("", error);
        if (!ModelState.IsValid) { await LoadAssignments(); return View(model); }
        model.TrangThai = "Đã lên lịch";
        db.LichHocs.Add(model);
        await db.SaveChangesAsync();
        TempData["Message"] = "Đã tạo lịch học.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateStatus(int id, string status)
    {
        var item = await db.LichHocs.FindAsync(id);
        if (item is not null && item.TrangThai != "Đã hủy" &&
            (status == "Đã hủy" || status == "Hoàn thành"))
        {
            item.TrangThai = status;
            await db.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }

    private async Task LoadAssignments()
    {
        var items = await db.PhanCongGiaSus.Include(x => x.GiaSu).Include(x => x.LopHoc)
            .Where(x => x.TrangThai == "Đang hiệu lực").ToListAsync();
        ViewBag.PhanCongGiaSuId = new SelectList(items, "Id", "Id");
        ViewBag.AssignmentLabels = items.ToDictionary(x => x.Id,
            x => $"{x.GiaSu?.HoTen} - {x.LopHoc?.TenLop}");
    }
}
