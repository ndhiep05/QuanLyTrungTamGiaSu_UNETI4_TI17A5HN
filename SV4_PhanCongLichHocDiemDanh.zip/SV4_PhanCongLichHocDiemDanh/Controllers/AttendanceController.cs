// Người thực hiện: SV4 - Nguyễn Việt Cường (hãy sửa tên/mã SV nếu cần)
// Nội dung: Điểm danh học viên đã xác nhận; chặn lịch hủy và bản ghi điểm danh trùng.
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SV4_PhanCongLichHocDiemDanh.Data;
using SV4_PhanCongLichHocDiemDanh.Models;

namespace SV4_PhanCongLichHocDiemDanh.Controllers;

public class AttendanceController(AppDbContext db) : Controller
{
    public async Task<IActionResult> Index(int? scheduleId)
    {
        var query = db.DiemDanhs.Include(x => x.DangKyLop)!.ThenInclude(x => x!.HocVien)
            .Include(x => x.LichHoc).AsQueryable();
        if (scheduleId.HasValue) query = query.Where(x => x.LichHocId == scheduleId.Value);
        ViewBag.Schedules = await db.LichHocs.Include(x => x.PhanCongGiaSu)!.ThenInclude(x => x!.LopHoc)
            .OrderByDescending(x => x.BatDau).ToListAsync();
        return View(await query.OrderByDescending(x => x.ThoiDiemDiemDanh).ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> Take(int id)
    {
        var schedule = await db.LichHocs.Include(x => x.PhanCongGiaSu)!.ThenInclude(x => x!.LopHoc)
            .FirstOrDefaultAsync(x => x.Id == id);
        if (schedule is null) return NotFound();
        if (schedule.TrangThai == "Đã hủy") { TempData["Error"] = "Không thể điểm danh lịch đã hủy."; return RedirectToAction(nameof(Index)); }
        var registrations = await db.DangKyLops.Include(x => x.HocVien)
            .Where(x => x.LopHocId == schedule.PhanCongGiaSu!.LopHocId && x.TrangThai == "Đã xác nhận")
            .OrderBy(x => x.HocVien!.HoTen).ToListAsync();
        ViewBag.Schedule = schedule;
        ViewBag.Existing = await db.DiemDanhs.Where(x => x.LichHocId == id).ToDictionaryAsync(x => x.DangKyLopId, x => x.TrangThai);
        return View(registrations);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(int scheduleId, int registrationId, string status, string? note)
    {
        var schedule = await db.LichHocs.Include(x => x.PhanCongGiaSu).FirstOrDefaultAsync(x => x.Id == scheduleId);
        if (schedule is null) return NotFound();
        if (schedule.TrangThai == "Đã hủy") { TempData["Error"] = "Không thể điểm danh lịch đã hủy."; return RedirectToAction(nameof(Index)); }
        var registration = await db.DangKyLops.FirstOrDefaultAsync(x => x.Id == registrationId &&
            x.TrangThai == "Đã xác nhận" && x.LopHocId == schedule.PhanCongGiaSu!.LopHocId);
        if (registration is null) { TempData["Error"] = "Học viên chưa xác nhận đăng ký lớp này."; return RedirectToAction(nameof(Take), new { id = scheduleId }); }
        if (status is not ("Có mặt" or "Vắng" or "Muộn")) status = "Có mặt";
        var row = await db.DiemDanhs.FirstOrDefaultAsync(x => x.LichHocId == scheduleId && x.DangKyLopId == registrationId);
        if (row is null) db.DiemDanhs.Add(new DiemDanh { LichHocId = scheduleId, DangKyLopId = registrationId, TrangThai = status, GhiChu = note });
        else { row.TrangThai = status; row.GhiChu = note; row.ThoiDiemDiemDanh = DateTime.Now; }
        await db.SaveChangesAsync();
        TempData["Message"] = "Đã lưu điểm danh.";
        return RedirectToAction(nameof(Take), new { id = scheduleId });
    }
}
