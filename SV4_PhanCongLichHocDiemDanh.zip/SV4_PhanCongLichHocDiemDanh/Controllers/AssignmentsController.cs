// Người thực hiện: SV4 - Nguyễn Việt Cường (hãy sửa tên/mã SV nếu cần)
// Nội dung: Danh sách và tạo phân công gia sư.
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SV4_PhanCongLichHocDiemDanh.Data;
using SV4_PhanCongLichHocDiemDanh.Models;

namespace SV4_PhanCongLichHocDiemDanh.Controllers;

public class AssignmentsController(AppDbContext db, ScheduleService service) : Controller
{
    public async Task<IActionResult> Index() => View(await db.PhanCongGiaSus
        .Include(x => x.GiaSu).Include(x => x.LopHoc).OrderByDescending(x => x.Id).ToListAsync());

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        await LoadOptions();
        return View(new PhanCongGiaSu());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(PhanCongGiaSu model)
    {
        var error = await service.ValidateAssignment(model.GiaSuId, model.LopHocId);
        if (error is not null) ModelState.AddModelError("", error);
        if (!ModelState.IsValid) { await LoadOptions(); return View(model); }
        model.NgayPhanCong = DateTime.Today;
        model.TrangThai = "Đang hiệu lực";
        db.PhanCongGiaSus.Add(model);
        await db.SaveChangesAsync();
        TempData["Message"] = "Đã tạo phân công.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Stop(int id)
    {
        var item = await db.PhanCongGiaSus.FindAsync(id);
        if (item is not null) { item.TrangThai = "Đã ngừng"; await db.SaveChangesAsync(); }
        return RedirectToAction(nameof(Index));
    }

    private async Task LoadOptions()
    {
        ViewBag.GiaSuId = new SelectList(await db.GiaSus.OrderBy(x => x.HoTen).ToListAsync(), "Id", "HoTen");
        ViewBag.LopHocId = new SelectList(await db.LopHocs.OrderBy(x => x.TenLop).ToListAsync(), "Id", "TenLop");
    }
}
